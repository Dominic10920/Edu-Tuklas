# gen bio quiz

A Pen created on CodePen.io. Original URL: [https://codepen.io/Rodolfo-Dominic-Guevarra/pen/wvVVQXE](https://codepen.io/Rodolfo-Dominic-Guevarra/pen/wvVVQXE).

